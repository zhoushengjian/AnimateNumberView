//
//  Cup.h
//  AnimateNumber
//
//  Created by zhoushengjian on 17/2/13.
//  Copyright © 2017年 zhoushengjian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CustomView : NSObject

+ (instancetype)viewWithColor:(UIColor *)color;

@end
